@extends('layout.mainlayout')

@section('title', 'Hapus Buku')

@section('content')
    <h2>Apakah kamu yakin ingin menghapus buku {{$book->tittle}} ?</h2>

    <div class="mt-5">
        <a href="/book-destroy/{{$book->slug}}" class="btn btn-primary me-5">Yakin</a>
        <a href="/books" class="btn btn-info">Tidak Yakin</a>
    </div>
@endsection