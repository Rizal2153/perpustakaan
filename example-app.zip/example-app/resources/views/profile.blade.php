@extends('layout.mainlayout')

@section('title', 'Profile')

@section('content')

    <div class="mt-5">
        <h3>Data Peminjaman Pengguna</h3>
        <a href="/cetak-buku" class="btn btn-primary" target="_blank" > Cetak Data </a>
        <x-rent-log-table :rentlog='$rent_logs' />
    </div>
@endsection 