@extends('layout.mainlayout')

@section('title', 'Users')

@section('content')
    <h1>List Pengguna Tidak Aktif</h1>

    <div class="mt-5 d-flex justify-content-end" >
        <a href="/users" class="btn btn-primary">Pengguna Aktif</a>
    </div>

    <div class="my-5">
        <table class="table" width="500px">
            <thead>
                <tr>
                    <th width="100px">No.</th>
                    <th width="300px">Username</th>
                    <th width="200px">Kelas</th>
                    <th width="400px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($registeredUsers as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->username }}</td>
                        <td>{{ $item->kelas }}</td>
                        <td>
                            {{-- <a href="{{ route("users.detail", $item->slug) }}">Detail</a> --}}
                            <a href="{{ route("users.detail", $item->slug) }}" class="btn btn-info">Pengguna Aktif</a>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection 