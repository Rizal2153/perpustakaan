@extends('layout.mainlayout')

@section('title', 'Hapus Pengguna')

@section('content')
    <h2>Apakah kamu yakin ingin menghapus pengguna {{$user->username}} ?</h2>

    <div class="mt-5">
        <a href="/user-destroy/{{$user->slug}}" class="btn btn-primary me-5">Yakin</a>
        <a href="/users" class="btn btn-info">Tidak Yakin</a>
    </div>
@endsection