{{-- @extends('layout.mainlayout')

@section('title', 'Add Users')

@section('content')
    
    <h1>Add New Category</h1>

    <div class="mt-5 w-50">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            
        @endif
        <form action="users-add" method="post">
            @csrf
            <div>
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" class="form-control" placeholder="Username User">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="name" class="form-control" placeholder="Password User">
                <label for="kelas" class="form-label">Kelas</label>
                <input type="text" name="kelas" id="kelas" class="form-control" placeholder="Kelas User">
            </div>

            <div class="mt-3">
                <button class="btn btn-success" type="submit">Save</button>
            </div>
        </form>
    </div>
@endsection  --}}