<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\BookRentContoller;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\RentLogController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DonasiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PublicController::class, 'index']);

Route::middleware('only_guest')->group(function () {
    Route::get('login', [AuthController::class, 'login'])->name('login');
    Route::post('login', [AuthController::class, 'authenticating']);
    Route::get('register', [AuthController::class, 'register']);
    Route::post('register', [AuthController::class, 'processregister']);

});

Route::middleware('auth')->group(function () {
    Route::get('logout',[AuthController::class, 'logout'])->name('logout.index');
    
    Route::get('profile', [UserController::class, 'profile'])->middleware('only_client');
    
    Route::get('donasi-book',[DonasiController::class, 'donasi']);
    Route::post('donasi-book',[DonasiController::class, 'store']);

    Route::get('book-rent', [BookRentContoller::class, 'index']);
    Route::post('book-rent', [BookRentContoller::class, 'store']);
    Route::get('cetak-buku', [BookRentContoller::class, 'cetak']);
    

Route::middleware('only_admin')->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

    Route::get('books', [BookController::class, 'index']);
    Route::get('book-add', [BookController::class, 'add']);
    Route::post('book-add', [BookController::class, 'store']);
    Route::get('book-edit/{slug}', [BookController::class, 'edit']);
    Route::post('book-edit/{slug}', [BookController::class, 'update']);
    Route::get('book-delete/{slug}', [BookController::class, 'delete']);
    Route::get('book-destroy/{slug}', [BookController::class, 'destroy']);

    Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
    Route::get('category-add', [CategoryController::class, 'add']);
    Route::post('category-add', [CategoryController::class, 'store']);
    Route::get('category-edit/{slug}', [CategoryController::class, 'edit']);
    Route::get('category-showarray/{slug}', [CategoryController::class, 'show']);
    Route::post('category-edit/{slug}', [CategoryController::class, 'update']);
    Route::get('category-delete/{slug}', [CategoryController::class, 'delete']);

    Route::get('users', [UserController::class, 'index'])->name('users.index');
    Route::get('registered-user',[UserController::class, 'registeredUser']);
    Route::get('user-detail/{slug}',[UserController::class, 'show'])->name('users.detail');
    Route::get('user-approve/{slug}',[UserController::class, 'approve'])->name('users.approve');
    Route::get('user-delete/{slug}',[UserController::class, 'delete'])->name('users.delete');
    Route::get('user-destroy/{slug}',[UserController::class, 'destroy'])->name('users.destroy');
    
    Route::get('rent-log', [RentLogController::class, 'index'])->name('rent-log.index');
    
    Route::get('book-return', [BookRentContoller::class, 'returnbook']);
    Route::post('book-return', [BookRentContoller::class, 'savereturnbook']);
});

});
