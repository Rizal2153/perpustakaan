<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return view('kategori', ['categories' => $categories]);
    }

    public function add()
    {
        return view('category-add');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|unique:categories|max:100'
        ]);
        
        $category = Category::create($request->all());
        return redirect('categories')->with('status','Data Kategori Berhasil Disimpan');
    }

    public function edit($slug)
    {
        $category = Category::where('slug', $slug)->first();
        return view('category-edit', ['category' => $category]);
        // return array('category' => $category);
        
    }
    public function show($slug)
    {
        $category = Category::where('slug', $slug)->first();
        // return view('category-edit', ['category' => $category]);
        return array($category);
        
    }

    public function update(Request $request, $slug)
    {
        // dd($category);
        $validated = $request->validate([
            'name' => 'required|unique:categories|max:100',
        ]);

        $category = Category::where('slug', $slug)->first();
        if ($category){
            $category->update($request->all());
            return redirect('categories')->with('status','Kategori berhasil diupdate');
        }else{
            return redirect('categories')->with('error','Kategori tidak ditemukan');
        }

        // return $category;
        
        // return redirect('categories')->with('status','Kategori berhasil Diupdate');
    }

    public function delete($slug)
    {
        // $category = Category::where('slug', $slug)->first();
        // return view('category-delete', ['category' => $category]);
        $category = Category::where('slug', $slug)->first();
        $category->delete();
        return redirect('categories')->with('status','Kategori berhasil Dihapus');
    }
}
