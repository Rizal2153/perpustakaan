<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Book;
use App\Models\User;
use App\Models\RentLogs;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\TryCatch;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class BookRentContoller extends Controller
{
    public function index()
    {
        $books = Book::all();
        return view('book-rent', [ 'books' => $books ]);
    }

    public function store(Request $request)
    {
        $request['rent_date'] = Carbon::now()->toDateString();
        $request['return_date'] = Carbon::now()->addDay(7)->toDateString();
        
        $book = Book::findOrFail($request->book_id)->only('status');

        if($book['status'] != 'in stock'){
            Session::flash('message', 'buku sedang dipinjam');
            Session::flash('alert-class', 'alert-danger');
            return redirect('book-rent');
        }
        else {
            $count = RentLogs::where('user_id', $request->user_id)->where('actual_return_date', null)
            ->count();
        
            if($count >= 3) {
                Session::flash('message', 'User sudah melebihi batas peminjaman');
                Session::flash('alert-class', 'alert-danger');
                return redirect('book-rent');
            }
            else{
                try {
                DB::beginTransaction();
                RentLogs::create($request->all());
                
                $book = Book::findOrFail($request->book_id);
                $book->status = 'not available';
                $book->save();
                DB::commit();

                Session::flash('message', 'Peminjaman Berhasil');
                Session::flash('alert-class', 'alert-success');   
                return redirect('book-rent');
            } catch (\Throwable $th) {
                DB::rollBack();
            }
         }
        }   
    }

    public function cetak()
    {
        $users = Auth::user()->id;
        $rent = RentLogs::where('user_id', $users)->where('actual_return_date', null)->get();
        // dd($rent);
        return view('cetak-buku', [ 'rentlogs' => $rent ]);
    }

    public function returnbook()
    {
        $users = User::where('id', '!=', 1)->where('status', '!=', 'inactive')->get();
        $books = Book::all();
        return view('return-book', ['users' => $users, 'books' => $books]);
    }

    public function savereturnbook(Request $request)
    {
        $rent = RentLogs::where('user_id', $request->user_id)->where('book_id', $request->book_id)->where('actual_return_date', null);
        $rentData = $rent->first();
        $countData = $rent->count();

        if($countData == 1) {
            $rentData->actual_return_date = Carbon::now()->toDateString();
            $rentData->save();

                        
            $book = Book::findOrFail($request->book_id);
            $book->status = 'in stock';
            $book->save();

            Session::flash('message', 'Berhasil Mengembalikan Buku');
            Session::flash('alert-class', 'alert-success');
            return redirect('book-return');
        }
        else{ 
            Session::flash('message', 'Buku Tidak Terdeteksi');
            Session::flash('alert-class', 'alert-danger');   
            return redirect('book-return');
        }
    }

}

// get()

// $users = User::where('id', '!=', 2)->where('status', '!='. 'inactive')->get();