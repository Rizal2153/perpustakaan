<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\RentLogs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function profile()
    {
        $rentlogs = RentLogs::with(['user','book'])->where('user_id', Auth::user()->id)->get();
        return view('profile', ['rent_logs' => $rentlogs]);
    }

    public function index()
    {
        $users = User::where('role_id', 2)->where('status', 'active')->get();
        return view('pengguna', ['users' => $users]);
    }

    // public function add(Request $request)
    // {
    //     $validated = $request->validate([
    //         'username' => 'required|unique:categories|max:100',
    //         'password' => 'required|max:100',
    //         'kelas' => 'required|max:100'
    //     ]);
    //     $users = User::create($request->all());
    //     return view('users-add')->with('status','Data Kategori Berhasil Disimpan');
    // }

    public function registeredUser()
    {
        $registeredUser = User::where('status', 'inactive')->where('role_id', 2)->get();
        return view('registered-user', ['registeredUsers' => $registeredUser]);
    }

    public function show($slug)
    {
        $user = User::where('slug', $slug)->first();
        $rentlogs = RentLogs::with(['user','book'])->where('user_id', $user->id)->get();
        return view('user-detail', ['user' => $user, 'rent_logs' => $rentlogs]);
    }

    public function approve($slug)
    {
        $user = User::where('slug', $slug)->first();
        $user->status = 'active';
        $user->save();

        // dd($user->status);
        
        return redirect()->route('users.index')->with('status', 'User berhasil di approve');
        // session()->flash("success", "User sukses ditambahkan");

        // return redirect()->route('editor.event.index');
    }

    public function delete($slug)
    {
        $user = User::where('slug', $slug)->first();
        return view('user-delete', ['user' => $user]);
    }

    public function destroy($slug)
    {
        $user = User::where('slug', $slug)->first();
        $user->delete();

        return redirect()->route('users.index')->with('status', 'User berhasil di hapus');
    }
}